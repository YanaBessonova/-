#include <stdio.h>

int lr1(void)
{
  float V,v1,t,v2;
  printf("V=");
  scanf("%f",&V);
  printf("v1=");
  scanf("%f",&v1);
  printf("t=");
  scanf("%f",&t);
  V=t*(v1+v2);
  v2=v1+V/t;

  printf("v2 = %f\n", v2); 
  return 0;