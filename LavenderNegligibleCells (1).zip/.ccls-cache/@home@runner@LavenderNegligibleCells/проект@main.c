#include <stdio.h>
#include "lr.h"
int main(void)
{
  int n;
  printf("Введите номер лабы: ");
  scanf("%d",&n);
  if(n==1)
    return lr1();
}