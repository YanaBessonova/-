#include <stdio.h>

int lr1(void)
  {
     float a = 1.0; // коэффициент при x^2
     float b = 0.2; // коэффициент при x
     float c = -0.35; // свободный член

     float discriminant = b * b - 4 * a * c;

     if (discriminant < 0) {
         printf("No real roots\n");
     } else if (discriminant == 0) {
         float root = -b / (2 * a);
         printf("Single root: %f\n", root);
     } else {
         float root1 = (-b + sqrt(discriminant)) / (2 * a);
         float root2 = (-b - sqrt(discriminant)) / (2 * a);
         printf("Root 1: %f\n", root1);
         printf("Root 2: %f\n", root2);
     }

     return 0;
 }
