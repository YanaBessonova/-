int lr1(void);
int lr2(void);
int lr3(void);
int lr4(void);
int lr5(void);
int lr6(void);
int lr7(void);